package com.hfad.testproject;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

/* The very first screen the user will see when they start the app. */
public class TopLevelActivity extends Activity {

    /* Typical onCreate method, using savedInstanceState and setContentView.
     * Nothing else needs to be done here, as all functionality in this view is tied to buttons. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_level);
    }

    /* onClick method for the button_create_group button. */
    public void onClick_createGroup(View view) {

        /* Creates EditText object for set_group_name in order to pull the text entered into it
         * and store it in String object group. */
        EditText groupName = findViewById(R.id.set_group_name);
        String group = groupName.getText().toString();

        /* Prevents the onClick method from completing if there is no information in the EditText. */
        if (group.matches("")) {

            /* Toast to let the user know what they should do. */
            Toast.makeText(TopLevelActivity.this,
                    "Please fill out group name",
                    Toast.LENGTH_SHORT).show();
        }
        /* Prevents the onClick method from completing if there are characters besides letters
         * in the EditText. */
        else if (!group.matches("[a-zA-Z]+")) {

            /* Toast to let the user know what they should do. */
            Toast.makeText(TopLevelActivity.this,
                    "Group name can contain only letters",
                    Toast.LENGTH_SHORT).show();
        }
        /* Allows the onClick method to complete if neither of the above apply. */
        else {

            /* Creates DatabaseHelper, then gives database to SQLiteDatabase object db. */
            DatabaseHelper helper = new DatabaseHelper(TopLevelActivity.this);
            SQLiteDatabase db = helper.getWritableDatabase();

            /* SQL statement that creates a table with the same name as the String obtained
             * from the EditText if a table of that name does not already exist. */
            db.execSQL("CREATE TABLE IF NOT EXISTS " + group + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "MEMBER TEXT, "
                    + "PHONE TEXT);");

            /* Creates Intent to CreateNewActivity, adds the name of the group created as an extra,
             * then starts the next activity. */
            Intent intent = new Intent(TopLevelActivity.this, CreateNewActivity.class);
            intent.putExtra("EXTRA_GROUP", group);
            startActivity(intent);
        }
    }

    /* onClick method for the button_gift_ideas button. */
    public void onClick_giftIdeas(View view) {

        /* Creates Intent to GiftIdeasActivity, then starts the activity. */
        Intent intent = new Intent(TopLevelActivity.this, GiftIdeasActivity.class);
        startActivity(intent);
    }
}