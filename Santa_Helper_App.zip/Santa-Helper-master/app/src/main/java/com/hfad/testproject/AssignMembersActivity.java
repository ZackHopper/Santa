package com.hfad.testproject;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Random;

/* Activity assigns members to each other using a random number to shift the positions of the members. */
public class AssignMembersActivity extends Activity {

    /* Some of these global objects, like some of the imported libraries above, are unused
     * or could be turned into instance objects. They were intended for use with a texting feature
     * that we simple didn't have time to fully implement. */
    private SQLiteDatabase db;
    DatabaseHelper helper;
    String group;
    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;

    Button textMembers;
    ArrayAdapter<String> memberArray;
    ArrayAdapter<String> assignedArray;

    /* onCreate method, which creates two ListView objects, then displays them side-by-side. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_members);

        /* Receives Intent, obtains group name from Extra, creates TextView, then sets
         * TextView text to the group name. */
        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUP");
        TextView groupName = findViewById(R.id.group_name);
        groupName.setText(group);

        /* Creates two ListView objects. One for the group members in their proper order,
         * the other for the same group members, but shifted randomly, indicating the group members
         * who receive gifts from the members in the other list. */
        ListView memberList = findViewById(R.id.list_members);
        ListView assignedList = findViewById(R.id.list_assigned);

        /* Creates SQLiteOpenHelper, then gives database to SQLiteDatabase object. */
        DatabaseHelper helper = new DatabaseHelper(this);
        db = helper.getReadableDatabase();

        /* Creates Cursor for database table. */
        Cursor cursor = db.query(group,
                new String[] {"MEMBER"},
                null, null, null, null, null);

        /* Creates ArrayAdapter for ListView to hold the names of the group members. */
        /*ArrayAdapter<String>*/ memberArray = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

        /* Activates Cursor by moving it to the first row of the table. */
        if (cursor.moveToFirst()) {

            /* Obtains name from the table, and adds it to memberArray. */
            memberArray.add(cursor.getString(cursor.getColumnIndex("MEMBER")));

            /* Repeats process until there are no more names to read from table. */
            while (cursor.moveToNext()) {

                memberArray.add(cursor.getString(cursor.getColumnIndex("MEMBER")));
            }
        }

        /* Creates ArrayAdapter for ListView to hold the names of the recipients. */
        /*ArrayAdapter<String>*/ assignedArray = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

        /* Creates a Random object, obtains the number of entries in the table, then creates a
         * random number with a value from zero to the number of entries minus one. */
        Random random = new Random();
        long numEntries = DatabaseUtils.queryNumEntries(db, group);
        int shift = random.nextInt((int) (numEntries - 1));

        /* for loop to add each member of memberArray to assignedArray. */
        for (int i = 0; i < numEntries; i++) {

            /* Adds generated random number to current value of i to one. This will determine
             * the "new" position of the entry in memberArray when assigned to assignedArray. */
            int sum = shift + i + 1;

            /* If the value calculated above is greater than or equal to the total number
             * of entries, the number of entries is subtracted from it. This ensures that
             * the code won't try to obtain data from an index that doesn't exist. */
            if (sum >= numEntries) {
                sum -= numEntries;
            }

            /* Assigns each member in memberArray to a "new" position in assignedArray. */
            assignedArray.add(memberArray.getItem(sum));
        }

        /* Sets adapters for both ListView objects. */
        memberList.setAdapter(memberArray);
        assignedList.setAdapter(assignedArray);

        /* This code was intended to work with the methods below. The idea was to have the app
         * text each group member which other member they had been assigned to get a gift for.
         * Unfortunately, the code didn't work as intended, and we simply didn't have enough
         * time to fix it before turning it in.
        textMembers = findViewById(R.id.assign_members);
        //Checking to see if app has permission to send SMS
        textMembers.setEnabled(false);
        if(checkPermission(Manifest.permission.SEND_SMS)){
            textMembers.setEnabled(true);
        }else{
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }
        */
    }


    public void onClick_textMembers(View view) {
        /*
        for(int i = 0; i < memberArray.getCount();i++){

            if(checkPermission(Manifest.permission.SEND_SMS))
            {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(assignedMemberPhone(i), null, Message(i), null, null);
                toastMessage("Message Sent");
            }else{toastMessage("Permission Denied");
            }
        }
        */
    }

    /*
    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this,permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    private String assignedMemberPhone(int position){

        String query = " SELECT PHONE FROM " + group +
                " WHERE MEMBER "+"='" + assignedArray.getItem(position) + "'";
        Cursor data = db.rawQuery(query, null);
        return data.toString();
    }
    private String Message(int position){
        return "Your partner for Secret Santa in " + group + " is " + memberArray.getItem(position).toString();

    }
    */
}