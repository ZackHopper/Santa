package com.hfad.testproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* DatabaseHelper object that extends SQLiteOpen Helper.
 * Due to how our code creates tables dynamically based on the group name entered by the user,
 * no table is created here, and instead this object is created just as a concrete version
 * of SQLiteOpenHelper in order to use its associated methods. */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "Santa";
    private static final int DB_VERSION = 1;

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {}

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}
}
