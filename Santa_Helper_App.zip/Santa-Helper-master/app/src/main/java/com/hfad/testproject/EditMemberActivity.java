package com.hfad.testproject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/* Activity to alter name and phone number of a group member. */
public class EditMemberActivity extends Activity {

    SQLiteDatabase db;
    String member;
    String phone;
    String group;
    long id;
    EditText editMember;
    EditText editPhone;
    Cursor cursor;

    /* onCreate method that populates TextView and EditView objects with group name,
     * member name, and phone number. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_member);

        /* Receives Intent, extracts passed id number and group name. */
        Intent receivedIntent = getIntent();
        id = receivedIntent.getLongExtra("EXTRA_ID", 0);
        group = receivedIntent.getStringExtra("EXTRA_GROUP");

        /* Creates TextView object for group_name, then sets text to the name of the group. */
        TextView groupView = findViewById(R.id.group_name);
        groupView.setText(group);

        /* Creates SQLiteOpenHelper to get database. */
        SQLiteOpenHelper helper = new DatabaseHelper(this);

        /* try-catch statement in case database is unavailable. */
        try {

            /* Gets database for SQLiteDatabase db. */
            db = helper.getReadableDatabase();

            /* Creates Cursor for group member. */
            cursor = db.query(group,
                    new String[] {"MEMBER", "PHONE"},
                    "_id = ?",
                    new String[] {Long.toString(id)},
                    null, null, null);

            /* Activates Cursor, then gets data in Cursor into String objects member and phone. */
            if (cursor.moveToFirst()) {

                member = cursor.getString(0);
                phone = cursor.getString(1);
            }
        }
        catch (Exception ex) {
            /* Creates Toast to tell user that database is unavailable. */
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        /* Creates EditText objects for edit_member and edit_phone, then sets to member name and
         * phone number found with Cursor. */
        editMember = findViewById(R.id.edit_member);
        editPhone = findViewById(R.id.edit_phone);
        editMember.setText(member);
        editPhone.setText(phone);
    }

    /* onClick method for update_member button. */
    public void onClick_updateMember(View view)
    {

        /* Extracts data in EditText fields. */
        String updateMember = editMember.getText().toString();
        String updatePhone = editPhone.getText().toString();

        /* If either field is blank, the rest of the method is prevented from completing. */
        if(updateMember.matches("") || updatePhone.matches(""))
        {
            /* Displays Toast to tell user what to do. */
            Toast.makeText(this,
                    "Please fill out both fields",
                    Toast.LENGTH_SHORT).show();
        }

        /* If both fields contain data, the rest of the method completes. */
        else {

            /* Changes values of member and phone objects to the values obtained
             * from the EditText fields, then creates ContentValues object containing
             * those values. */
            member = updateMember;
            phone = updatePhone;
            ContentValues values = new ContentValues();
            values.put("MEMBER", member);
            values.put("PHONE", phone);

            /* Creates single-capacity String array containing the id of the member. */
            String[] args = new String[1];
            args[0] = Long.toString(id);

            /* Updates entry for group member in the database, then displays Toast to user
             * that the update was made. */
            db.update(group, values, "_id = ?", args);
            toastMessage(updateMember + " updated");

            /* Finishes activity, returning user to GroupMembersActivity. */
            finish();
        }

    }

    /* onClick method for delete_memeber button. */
    public void onClick_deleteMember(View view)
    {

        /* Clears editMember and editPhone fields. */
        editMember.getText().clear();
        editPhone.getText().clear();

        /* Creates single-capacity String array containing group member's id. */
        String[] args = new String[1];
        args[0] = Long.toString(id);

        /* Deletes entry in table for group member, then displays Toast to user
         * that the deletion was made. */
        db.delete(group, "_id = ?", args);
        toastMessage(member + " deleted");

        /* Finished activity, returning user to GroupMembersActivity. */
        finish();
    }

    /* Method to make creating Toast objects easier. */
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    /* When activity is destroyed, Cursor and database objects are closed. */
    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }
}