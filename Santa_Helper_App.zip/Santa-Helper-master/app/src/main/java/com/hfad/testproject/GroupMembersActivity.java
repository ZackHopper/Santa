package com.hfad.testproject;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

/* Activity to display group members alongside their phone numbers. */
public class GroupMembersActivity extends Activity {

    private SQLiteDatabase db;
    private Cursor cursor;
    String group;
    SimpleCursorAdapter memberListAdapter;
    SimpleCursorAdapter phoneListAdapter;

    /* onCreate method which receives the name of the group from the received Intent,
     * then creates lists of group members and their phone numbers. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_members);

        /* Receives Intent, extracts name of the group passed as an Extra, then sets TextView
         * to that name. */
        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUP");
        TextView groupView = findViewById(R.id.group_name);
        groupView.setText(group);

        /* Initiates createList method. */
        createList();
    }

    /* Creates lists of group members and their phone numbers. */
    private void createList() {

        /* Creates ListView objects for list_members and list_phones. This allows them to be
         * displayed side-by-side, though unfortunately they don't scroll together. */
        ListView memberList = findViewById(R.id.list_members);
        ListView phoneList = findViewById(R.id.list_phones);

        /* Creates SQLiteOpenHelper to obtain database. */
        SQLiteOpenHelper helper = new DatabaseHelper(this);

        /* try-catch statement if database is unavailable. */
        try {

            /* Puts database into SQLiteDatabase db. */
            db = helper.getReadableDatabase();

            /* Creates Cursor for database. */
            cursor = db.query(group,
                    new String[] {"_id", "MEMBER", "PHONE"},
                    null, null, null, null, null);

            /* Creates SimpleCursorAdapters for MEMBER and PHONE columns of the table. */
            memberListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"MEMBER"},
                    new int[] {android.R.id.text1},
                    0);

            phoneListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"PHONE"},
                    new int[] {android.R.id.text1},
                    0);

            /* Sets adapters to ListView objects. */
            memberList.setAdapter(memberListAdapter);
            phoneList.setAdapter(phoneListAdapter);
        }
        catch(SQLiteException e) {
            /* Displays Toast, telling the user that the database is unavailable. */
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }

        /* Creates OnItemClickListener for the ListView objects, so that clicking on a member name
         * or phone number will allow the user to edit the corresponding member's namd and number. */
        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> listMembers,
                                            View itemView,
                                            int position,
                                            long id) {

                        /* Creates Intent for EditMemberActivity, puts group name and id of the
                         * selected member as Extras, and starts activity. */
                        Intent intent = new Intent(GroupMembersActivity.this,
                                EditMemberActivity.class);
                        intent.putExtra("EXTRA_GROUP", group);
                        intent.putExtra("EXTRA_ID", id);
                        startActivity(intent);
                    }
                };

        /* Assigns OnItemClickListener to both ListView objects. */
        memberList.setOnItemClickListener(itemClickListener);
        phoneList.setOnItemClickListener(itemClickListener);
    }

    /* onClick method for assign_members button. */
    public void onClick_assignMembers(View view) {

        /* Extracts the number of entries in database table, then stores the result in Long object. */
        long numEntries = DatabaseUtils.queryNumEntries(db, group);

        /* If there are fewer than three entries in table, the method is prevented from completing. */
        if (numEntries < 3) {

            /* Calculates how many entries need to be added to the table to have at least three
             * entries, then displays result to user through Toast. */
            int difference = 3 - (int) numEntries;
            if (difference > 1) {
                toastMessage("Group needs " + difference + " more members");
            }
            else {
                toastMessage("Group needs 1 more member");
            }
        }

        /* If there are at least three entries in table, rest of the method is completed. */
        else {

            /* Creates Intent to AssignMembersActivity, puts group name as Extra,
             * then starts activity. */
            Intent intent = new Intent(GroupMembersActivity.this,
                    AssignMembersActivity.class);
            intent.putExtra("EXTRA_GROUP", group);
            startActivity(intent);
        }
    }

    /* Method to make Toast creation easier. */
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    /* onResume method that refreshes the ListViews. */
    @Override
    public void onResume() {
        super.onResume();

        /* Creates a new Cursor object. */
        Cursor newCursor = db.query(group,
                new String[] {"_id", "MEMBER", "PHONE"},
                null, null, null, null, null);

        /* Swaps out the old Cursor with the new one. */
        memberListAdapter.changeCursor(newCursor);
        phoneListAdapter.changeCursor(newCursor);
    }

    /* Closes database and Cursor when activity is destroyed. */
    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }
}