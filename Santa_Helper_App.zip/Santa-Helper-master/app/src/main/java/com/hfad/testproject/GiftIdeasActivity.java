package com.hfad.testproject;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/* Displays a list of gift ideas to the user. */
public class GiftIdeasActivity extends Activity {

    private TextView top10;

    /* onCreate method which creates a TextView object for listTop10. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gift_ideas);

        top10 = findViewById(R.id.listTop10);
    }

    /* onClick method for buttonTop10. */
    public void onClick_top10(View view) {

        /* Passes a String for the address of a JSON file we created and uploaded to GitHub. */
        new JSONTask().execute("https://raw.githubusercontent.com/ZackHopper/Santa/master/giftIdeas.json");
    }

    /* JSONTask which parses the JSON file for information. */
    public class JSONTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {

            /* HttpURLConnection object to connect to the URL. */
            HttpURLConnection connection = null;

            /* BufferedReader object to obtain the information in the URL. */
            BufferedReader reader = null;

            /* try-catch statement for issues with URL connection and JSON objects. */
            try {

                /* Creates URL object using passed String. */
                URL url = new URL(params[0]);

                /* Creates connection using URL. */
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                /* Creates InputStream object, earlier BufferedReader object set up to read from
                 * that InputStream object, and StringBuffer object created to read from the
                 * the Buffered reader object. */
                InputStream stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();

                /* StringBuffer object reads from BufferedReader object, parsing the stream
                 * for information. */
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                /* Stores StringBuffer object as a String. */
                String finalJSON = buffer.toString();

                /* Creates JSONObject from the String, obtains the JSONArray "ideas" from the
                 * JSONObject, then obtains the first (and only) JSONObject in the JSONArray. */
                JSONObject parentObject = new JSONObject(finalJSON);
                JSONArray parentArray = parentObject.getJSONArray("ideas");
                JSONObject finalObject = parentArray.getJSONObject(0);

                /* Creates ArrayList to store Strings taken from JSONObject. */
                ArrayList<String> arrayList = new ArrayList<>();

                /* Creates String to store formatted Strings from ArrayList. This String is
                 * is then returned at the end of the method. */
                String returnList = new String();

                /* Adds all values in JSONObject to ArrayList as formatted Strings, then stores
                 * those Strings in the String object returnList. */
                for (int i = 0; i < finalObject.length(); i++) {
                    arrayList.add((i + 1) + ": " + finalObject.getString("" + i) + "\n");
                    returnList = returnList.concat(arrayList.get(i));
                }

                /* Returns the String object returnList, which now contains all values in the
                 * JSONObject. */
                return returnList;
            }
            catch (Exception e) {
                e.printStackTrace();
            }

            /* When method is finished, the connection and stream are both closed. IO exceptions
             * are caught and traced. */
            finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            /* If code couldn't complete due to exception, method returns null. */
            return null;
        }

        /* After code above has finished, TextView is set to the text of the returned String,
         * which contains formatted Strings of all values stored in the JSON object. */
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            top10.setText(result);
        }
    }
}