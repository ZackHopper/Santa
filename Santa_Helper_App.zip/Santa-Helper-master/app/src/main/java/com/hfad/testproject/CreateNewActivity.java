package com.hfad.testproject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.database.DatabaseUtils;

/* Activity which allows the user to add members to the created group. */
public class CreateNewActivity extends Activity {

    /* Global variable used to contain the name of the created group. */
    String group;

    /* onCreate method receives the name of the group from the passed intent and changes the
     * TextView to display that name. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new);

        /* Creates Intent to obtain the group name of the created group, stores that name
         * in the group object. */
        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUP");

        /* Creates TextView object for group_name, then sets its text to the name of the group. */
        TextView groupName = findViewById(R.id.group_name);
        groupName.setText(group);
    }

    /* onClick method for button_add_member button. */
    public void onClick_addMember(View view) {

        /* Creates EditText objects for add_member and add_phone, then obtains the data
         * entered into those objects. */
        EditText addMember = findViewById(R.id.add_member);
        EditText addPhone = findViewById(R.id.add_phone);
        String member = addMember.getText().toString();
        String phone = addPhone.getText().toString();

        /* If either EditText is blank, the onClick method is prevented from completing,
         * and a Toast is displayed to tell the user what to do. */
        if (member.matches("") || phone.matches("")) {
            toastMessage("Please fill out both fields");
        }

        /* If both EditTexts have been filled out, the rest of the onClick method completes. */
        else {

            /* Creates DatabaseHelper, then gives database to SQLiteDatabase object db. */
            DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
            SQLiteDatabase db = helper.getWritableDatabase();

            /* Creates ContentValues object containing data for member name and phone number,
             * then inserts that data into the database. */
            ContentValues values = new ContentValues();
            values.put("MEMBER", member);
            values.put("PHONE", phone);
            db.insert(group, null, values);

            /* Toast popup to confirm to user that member was added to database. */
            toastMessage(member + " added to group.");

            /* Clears EditText fields on completion to allow for multiple entries. */
            addMember.getText().clear();
            addPhone.getText().clear();
        }
    }

    /* onClick method for button_view_group button. */
    public void onClick_viewGroup(View view) {

        /* Creates DatabaseHelper, then puts database into SQLiteDatabase object db. */
        DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();

        /* Creates Intent to GroupMembersActivity, puts name of the group as an Extra, then starts
         * activity. */
        Intent intent = new Intent(CreateNewActivity.this, GroupMembersActivity.class);
        intent.putExtra("EXTRA_GROUP", group);
        startActivity(intent);
    }

    /* Method to more easily create Toast messages. */
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}