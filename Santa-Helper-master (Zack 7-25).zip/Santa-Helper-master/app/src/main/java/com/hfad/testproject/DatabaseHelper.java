package com.hfad.testproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "Santa";
    private static final int DB_VERSION = 1;
    private String groupName = "";

    DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        updateMyDatabase(db, groupName, 0, DB_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        updateMyDatabase(db, groupName, oldVersion, newVersion);
    }

    public void setGroupName (String groupName) {
        this.groupName = groupName;
    }

    public String getGroupName() {
        return this.groupName;
    }

    public static void insertPerson(SQLiteDatabase db, String groupName, String name, int phone) {
        ContentValues personValues = new ContentValues();
        personValues.put("NAME", name);
        personValues.put("PHONE", phone);
        db.insert(groupName, null, personValues);
    }

    private void updateMyDatabase(SQLiteDatabase db, String groupName, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            String tableString = ("CREATE TABLE " + groupName + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "NAME TEXT, "
                    + "PHONE INTEGER);");
            db.execSQL(tableString);
        }
    }
}
