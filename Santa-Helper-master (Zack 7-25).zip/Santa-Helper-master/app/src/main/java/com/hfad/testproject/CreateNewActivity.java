package com.hfad.testproject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.database.DatabaseUtils;

public class CreateNewActivity extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new);
    }

    public void onClick_addPerson(final View view)
    {

        Button addPersonButton = (Button) findViewById(R.id.button_add_person);

        addPersonButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                EditText groupName = (EditText) findViewById(R.id.group_name);
                EditText addPerson = (EditText) findViewById(R.id.add_person);
                EditText addPhone = (EditText) findViewById(R.id.add_phone);

                String group = groupName.getText().toString();
                String name = addPerson.getText().toString();
                String phone = addPhone.getText().toString();

                if (name.matches("") || phone.matches("") || group.matches("")) {
                    Toast.makeText(CreateNewActivity.this,
                            (CharSequence) "Please fill out all fields",
                            Toast.LENGTH_SHORT).show();
                }
                else {

                    DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
                    SQLiteDatabase db = helper.getWritableDatabase();

                    /*
                    if (db == null) {
                        helper.setGroupName(group);
                        helper.onCreate(db);
                        Toast.makeText(CreateNewActivity.this,
                                "If check",
                                Toast.LENGTH_SHORT).show();
                    }
                    */

                    db.execSQL("CREATE TABLE IF NOT EXISTS " + group + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                            + "NAME TEXT, "
                            + "PHONE INTEGER);");

                    helper.insertPerson(db, group, name, Integer.parseInt(phone));

                    /*
                    Toast.makeText(CreateNewActivity.this,
                            "Added " + name + ". Number: " + phone,
                            Toast.LENGTH_SHORT).show();
                            */

                    //db.close();

                    addPerson.getText().clear();
                    addPhone.getText().clear();
                }
            }
        });
    }

    public void onClick_createGroup(View view) {

        Button createGroupButton = (Button) findViewById(R.id.button_create_group);

        createGroupButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                EditText groupName = (EditText) findViewById(R.id.group_name);

                String group = groupName.getText().toString();

                DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
                SQLiteDatabase db = helper.getWritableDatabase();

                db.execSQL("CREATE TABLE IF NOT EXISTS " + group + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + "NAME TEXT, "
                        + "PHONE INTEGER);");

                long numEntries = DatabaseUtils.queryNumEntries(db, group);

                if (numEntries < 3) {
                    int difference = 3 - (int) numEntries;
                    Toast.makeText(CreateNewActivity.this,
                            "Need " + difference + " more entries",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}