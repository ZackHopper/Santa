package com.hfad.testproject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class EditMemberActivity extends Activity {

    public static final String TAG = "MemberActivity";
    SQLiteDatabase db;
    String member;
    String phone;
    String group;
    long id;
    EditText editMember;
    EditText editPhone;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_member);

        editMember = findViewById(R.id.edit_member);
        editPhone = findViewById(R.id.edit_phone);

        Intent receivedIntent = getIntent();

        id = receivedIntent.getLongExtra("EXTRA_ID", 0);
        group = receivedIntent.getStringExtra("EXTRA_GROUPNAME");

        TextView groupView = findViewById(R.id.group_name);
        groupView.setText(group);

        SQLiteOpenHelper dbHelper = new DatabaseHelper(this);

        try {
            db = dbHelper.getReadableDatabase();
            cursor = db.query(group,
                    new String[] {"MEMBER", "PHONE"},
                    "_id = ?",
                    new String[] {Long.toString(id)},
                    null, null, null);

            if (cursor.moveToFirst()) {

                member = cursor.getString(0);
                phone = cursor.getString(1).toString();
            }
        }

        catch (Exception ex) {

        }

        editMember.setText(member);
        editPhone.setText(phone);
    }

    public void onClick_updateMember(View view)
    {

        String updateMember = editMember.getText().toString();
        String updatePhone = editPhone.getText().toString();

        if(updateMember.matches("") || updatePhone.matches(""))
        {
            Toast.makeText(this,
                    "Please fill out both fields",
                    Toast.LENGTH_SHORT).show();
        }
        else {

            member = updateMember;
            phone = updatePhone;

            ContentValues values = new ContentValues();
            values.put("MEMBER", member);
            values.put("PHONE", phone);

            String[] args = new String[1];
            args[0] = Long.toString(id);

            db.update(group, values, "_id = ?", args);
            Log.d(TAG, "updateMember: " + member + "changed to " + updateMember);
            Log.d(TAG, "updatePhone: " + phone + "changed to " + updatePhone);
            toastMessage(updateMember + " updated");
        }

    }

    public void onClick_deleteMember(View view)
    {

        editMember.getText().clear();
        editPhone.getText().clear();

        String[] args = new String[1];
        args[0] = Long.toString(id);

        db.delete(group, "_id = ?", args);

        Log.d(TAG, "deleteMember: " + member + " deleted");

        toastMessage(member + " deleted");

        finish();
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }
}