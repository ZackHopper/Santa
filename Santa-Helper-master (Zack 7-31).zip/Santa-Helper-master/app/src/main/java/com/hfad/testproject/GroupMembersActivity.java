package com.hfad.testproject;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class GroupMembersActivity extends Activity {

    private SQLiteDatabase db;
    private Cursor cursor;
    String group;
    SimpleCursorAdapter memberListAdapter;
    SimpleCursorAdapter phoneListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_members);

        TextView groupView = findViewById(R.id.group_name);


        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUPNAME");

        groupView.setText(group);

        createList();
    }

    private void createList() {

        ListView memberList = findViewById(R.id.list_members);
        ListView phoneList = findViewById(R.id.list_phones);

        SQLiteOpenHelper dbHelper = new DatabaseHelper(this);
        try {
            db = dbHelper.getReadableDatabase();
            cursor = db.query(group,
                    new String[] {"_id", "MEMBER", "PHONE"},
                    null, null, null, null, null);

            memberListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"MEMBER"},
                    new int[] {android.R.id.text1},
                    0);

            memberList.setAdapter(memberListAdapter);

            phoneListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"PHONE"},
                    new int[] {android.R.id.text1},
                    0);

            phoneList.setAdapter(phoneListAdapter);
        }
        catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }
        //Create the listener
        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> listMembers,
                                            View itemView,
                                            int position,
                                            long id) {
                        //Pass the drink the user click on to DrinkActivity
                        Intent intent = new Intent(GroupMembersActivity.this,
                                EditMemberActivity.class);
                        intent.putExtra("EXTRA_GROUPNAME", group);
                        intent.putExtra("EXTRA_ID", id);
                        startActivity(intent);
                    }
                };
        //Assign the listener to the list view
        memberList.setOnItemClickListener(itemClickListener);
        phoneList.setOnItemClickListener(itemClickListener);
    }

    public void onClick_assignMembers(View view) {

        long numEntries = DatabaseUtils.queryNumEntries(db, group);

        if (numEntries < 3) {
            int difference = 3 - (int) numEntries;
            if (difference > 1) {
                toastMessage("Group needs " + difference + " more members");
            }
            else {
                toastMessage("Group needs 1 more member");
            }
        }
        else {

            Intent intent = new Intent(GroupMembersActivity.this,
                    AssignMembersActivity.class);
            intent.putExtra("EXTRA_GROUPNAME", group);
            startActivity(intent);
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();

        Cursor newCursor = db.query(group,
                new String[] {"_id", "MEMBER", "PHONE"},
                null, null, null, null, null);

        memberListAdapter.changeCursor(newCursor);
        phoneListAdapter.changeCursor(newCursor);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }
}