package com.hfad.testproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Random;

public class AssignMembersActivity extends AppCompatActivity {

    private SQLiteDatabase db;
    String group;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_members);

        Intent receivedIntent = getIntent();

        group = receivedIntent.getStringExtra("EXTRA_GROUPNAME");
        TextView groupName = findViewById(R.id.group_name);
        groupName.setText(group);

        ListView memberList = findViewById(R.id.list_members);
        ListView assignedList = findViewById(R.id.list_assigned);

        SQLiteOpenHelper dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        long numEntries = DatabaseUtils.queryNumEntries(db, group);

        Cursor cursor = db.query(group,
                new String[] {"MEMBER"},
                null, null, null, null, null);

        ArrayAdapter<String> memberArray = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);


        if (cursor.moveToFirst()) {

            memberArray.add(cursor.getString(cursor.getColumnIndex("MEMBER")));

            while (cursor.moveToNext()) {

                memberArray.add(cursor.getString(cursor.getColumnIndex("MEMBER")));
            }
        }

        ArrayAdapter<String> assignedArray = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

        Random random = new Random();

        int shift = random.nextInt((int) (numEntries - 1));

        for (int i = 0; i < numEntries; i++) {

            int sum = shift + i + 1;

            if (sum >= numEntries) {
                sum -= numEntries;
            }

            assignedArray.add(memberArray.getItem(sum));
        }

        memberList.setAdapter(memberArray);
        assignedList.setAdapter(assignedArray);
    }
}