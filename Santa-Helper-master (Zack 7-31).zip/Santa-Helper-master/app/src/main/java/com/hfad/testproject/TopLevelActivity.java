package com.hfad.testproject;

import android.app.Activity;
import android.content.Intent;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class TopLevelActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_level);
    }

    public void onClick_createGroup(View view) {

        EditText groupName = findViewById(R.id.set_group_name);

        String group = groupName.getText().toString();

        if (group.matches("")) {
            Toast.makeText(TopLevelActivity.this,
                    "Please fill out group name",
                    Toast.LENGTH_SHORT).show();
        }
        else if (!group.matches("[a-zA-Z]+")) {
            Toast.makeText(TopLevelActivity.this,
                    "Group name can contain only letters",
                    Toast.LENGTH_SHORT).show();
        }
        else {

            DatabaseHelper helper = new DatabaseHelper(TopLevelActivity.this);
            SQLiteDatabase db = helper.getWritableDatabase();

            db.execSQL("CREATE TABLE IF NOT EXISTS " + group + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "MEMBER TEXT, "
                    + "PHONE TEXT);");

            Intent intent = new Intent(TopLevelActivity.this, CreateNewActivity.class);
            intent.putExtra("EXTRA_GROUPNAME", group);
            startActivity(intent);
        }
    }
}