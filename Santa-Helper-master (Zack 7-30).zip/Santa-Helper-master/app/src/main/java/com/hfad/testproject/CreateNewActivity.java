package com.hfad.testproject;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.database.DatabaseUtils;

public class CreateNewActivity extends Activity {

    String group;
    TextView groupName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new);

        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUPNAME");

        groupName = findViewById(R.id.group_name);
        groupName.setText(group);
    }

    public void onClick_addMember(View view) {

        EditText addMember = findViewById(R.id.add_member);
        EditText addPhone = findViewById(R.id.add_phone);

        String member = addMember.getText().toString();
        String phone = addPhone.getText().toString();

        if (member.matches("") || phone.matches("")) {
            Toast.makeText(CreateNewActivity.this,
                    "Please fill out both fields",
                    Toast.LENGTH_SHORT).show();
        }
        else {

            DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
            SQLiteDatabase db = helper.getWritableDatabase();

            helper.insertPerson(db, group, member, phone);

            addMember.getText().clear();
            addPhone.getText().clear();
        }
    }

    public void onClick_viewGroup(View view) {

        DatabaseHelper helper = new DatabaseHelper(CreateNewActivity.this);
        SQLiteDatabase db = helper.getWritableDatabase();

        /*
        db.execSQL("CREATE TABLE IF NOT EXISTS " + group + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "NAME TEXT, "
                + "PHONE TEXT);");
        */

        long numEntries = DatabaseUtils.queryNumEntries(db, group);

        if (numEntries < 3) {
            int difference = 3 - (int) numEntries;
            if (difference > 1) {
                Toast.makeText(CreateNewActivity.this,
                        "Group needs " + difference + " more members",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(CreateNewActivity.this,
                        "Group needs 1 more member",
                        Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Intent intent = new Intent(CreateNewActivity.this, GroupMembersActivity.class);
            intent.putExtra("EXTRA_GROUPNAME", group);
            startActivity(intent);
        }
    }
}