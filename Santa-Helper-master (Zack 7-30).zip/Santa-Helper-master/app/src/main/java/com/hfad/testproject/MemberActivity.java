package com.hfad.testproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MemberActivity extends Activity {

    SQLiteDatabase db;
    String name;
    String number;
    String groupName;
    long id;
    boolean delete;
    EditText editName;
    EditText editNumber;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member);

        editName = findViewById(R.id.edit_person);
        editNumber = findViewById(R.id.edit_phone);

        Intent receivedIntent = getIntent();

        id = receivedIntent.getLongExtra("EXTRA_ID", 0);
        groupName = receivedIntent.getStringExtra("EXTRA_GROUPNAME");

        delete = false;

        SQLiteOpenHelper dbHelper = new DatabaseHelper(this);

        try {
            db = dbHelper.getReadableDatabase();
            cursor = db.query(groupName,
                    new String[] {"MEMBER", "PHONE"},
                    "_id = ?",
                    new String[] {Long.toString(id)},
                    null, null, null);

            if (cursor.moveToFirst()) {

                name = cursor.getString(0);
                number = cursor.getString(1).toString();
            }
        }

        catch (Exception ex) {

        }

        editName.setText(name);
        editNumber.setText(number);
    }

    public void onClick_deleteMember(View view) {

        editName.getText().clear();
        editNumber.getText().clear();

        db.execSQL("DELETE FROM " + groupName + " WHERE _id=" + id + ";");

        //delete = true;

        finish();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();

        /*
        if (delete) {

            db.execSQL("DELETE FROM " + groupName + " WHERE _id=" + id + ";");
        }
        */
        cursor.close();
        db.close();
    }
}