package com.hfad.testproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class GroupMembersActivity extends Activity {

    private SQLiteDatabase db;
    private Cursor cursor;
    String group;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_members);
        ListView listNames = findViewById(R.id.list_names);
        ListView listNumbers = findViewById(R.id.list_numbers);

        Intent receivedIntent = getIntent();
        group = receivedIntent.getStringExtra("EXTRA_GROUPNAME");

        SQLiteOpenHelper dbHelper = new DatabaseHelper(this);
        try {
            db = dbHelper.getReadableDatabase();
            cursor = db.query(group,
                    new String[] {"_id", "MEMBER", "PHONE"},
                    null, null, null, null, null);

            SimpleCursorAdapter nameListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"MEMBER"},
                    new int[] {android.R.id.text1},
                    0);

            listNames.setAdapter(nameListAdapter);

            SimpleCursorAdapter numberListAdapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1,
                    cursor,
                    new String[] {"PHONE"},
                    new int[] {android.R.id.text1},
                    0);

            listNumbers.setAdapter(numberListAdapter);
        }
        catch(SQLiteException e) {
            Toast toast = Toast.makeText(this, "Database unavailable", Toast.LENGTH_SHORT);
            toast.show();
        }
        //Create the listener
        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> listMembers,
                                            View itemView,
                                            int position,
                                            long id) {
                        //Pass the drink the user click on to DrinkActivity
                        Intent intent = new Intent(GroupMembersActivity.this,
                                MemberActivity.class);
                        intent.putExtra("EXTRA_GROUPNAME", group);
                        intent.putExtra("EXTRA_ID", id);
                        startActivity(intent);
                    }
                };
        //Assign the listener to the list view
        listNames.setOnItemClickListener(itemClickListener);
        listNumbers.setOnItemClickListener(itemClickListener);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cursor.close();
        db.close();
    }
}